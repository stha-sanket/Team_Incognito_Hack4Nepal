from django.urls import path
from . import views

app_name = 'docex'

urlpatterns = [
    path('', views.display_text, name='display_text'),
] 